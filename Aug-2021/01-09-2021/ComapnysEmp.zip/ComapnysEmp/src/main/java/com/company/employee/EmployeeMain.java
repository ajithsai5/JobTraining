package com.company.employee;

import java.util.Map;

import com.company.employee.bo.EmployeeBO;
import com.company.employee.bo.EmployeeBOImp;
import com.company.entities.Employee;

public class EmployeeMain 
{
    public static void main( String[] args )
    {
    	EmployeeBO employeeBO  = new  EmployeeBOImp();
    	Map<Integer, Employee> list = employeeBO.createEmployee();
    	employeeBO.printEmployee(list);
    	employeeBO.findEmployee(001732451);
    	employeeBO.deleteEmployee(001732451);
    	employeeBO.updateEmployee("Hyd",001732451);
       //8 System.out.println( "Hello World!" );
    }
}
