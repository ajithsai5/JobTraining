package com.company.workers.bo;

import java.util.Map;
import com.company.dao.CrudDAO;
import com.company.dao.CrudDAOImpl;
import com.company.entities.Workers;

public class WorkersBOImpl implements WorkersBO {
	
	CrudDAO<Workers> crudDAO = new CrudDAOImpl();

	public Map<Integer, Workers> createWorker() {
		return crudDAO.create();
	}

	public Workers printWorker(Map list) {
		return crudDAO.print(list);
	}

	public Workers findWorker(Integer empid) {
		return crudDAO.find(empid);
	}

	public Workers deleteWorker(Integer empid) {
		return crudDAO.delete(empid);
	}

	public Workers updateWorker(String Location, Integer empid) {
		return crudDAO.update(Location,empid);
	}

}
